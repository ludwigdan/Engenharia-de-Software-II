<?php
    
    $dsn = "mysql:host=localhost;dbname=ads";
    $usuario = "root";
    $senha = "root";

    $bd = new PDO($dsn, $usuario, $senha);
?>
